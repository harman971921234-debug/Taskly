/* ===================================================
   TASKLY — Coming Soon Website
   Application JavaScript
   =================================================== */

document.addEventListener('DOMContentLoaded', () => {
  // ===== Loader =====
  const loader = document.getElementById('loader');
  window.addEventListener('load', () => {
    setTimeout(() => {
      loader.classList.add('hidden');
    }, 800);
  });

  // Safety fallback — hide loader after 3s regardless
  setTimeout(() => {
    loader.classList.add('hidden');
  }, 3000);

  // ===== Navbar Scroll Effect =====
  const navbar = document.getElementById('navbar');
  const scrollIndicator = document.getElementById('scroll-indicator');

  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }

    // Hide scroll indicator
    if (scrollIndicator && window.scrollY > 200) {
      scrollIndicator.style.opacity = '0';
    } else if (scrollIndicator) {
      scrollIndicator.style.opacity = '';
    }
  });

  // ===== Active Nav Link on Scroll =====
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');

  const observerOptions = {
    root: null,
    rootMargin: '-40% 0px -60% 0px',
    threshold: 0
  };

  const sectionObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.id;
        navLinks.forEach(link => {
          link.classList.toggle('active', link.getAttribute('href') === `#${id}`);
        });
      }
    });
  }, observerOptions);

  sections.forEach(section => sectionObserver.observe(section));

  // ===== Mobile Navigation =====
  const mobileToggle = document.getElementById('mobile-toggle');
  const mobileOverlay = document.getElementById('mobile-nav-overlay');
  const mobileLinks = document.querySelectorAll('.mobile-nav-link');

  function toggleMobileNav() {
    mobileToggle.classList.toggle('active');
    mobileOverlay.classList.toggle('active');
    document.body.style.overflow = mobileOverlay.classList.contains('active') ? 'hidden' : '';
  }

  mobileToggle.addEventListener('click', toggleMobileNav);

  mobileLinks.forEach(link => {
    link.addEventListener('click', () => {
      toggleMobileNav();
    });
  });

  // ===== Learn More Modal =====
  const learnMoreBtn = document.getElementById('learn-more-btn');
  const footerLearnMore = document.getElementById('footer-learn-more');
  const learnMoreModal = document.getElementById('learn-more-modal');
  const modalCloseBtn = document.getElementById('modal-close-btn');
  const modalCtaBtn = document.getElementById('modal-cta-btn');

  function openModal() {
    if (learnMoreModal) {
      learnMoreModal.classList.add('active');
      learnMoreModal.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
    }
  }

  function closeModal() {
    if (learnMoreModal) {
      learnMoreModal.classList.remove('active');
      learnMoreModal.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
    }
  }

  if (learnMoreBtn) learnMoreBtn.addEventListener('click', openModal);
  if (footerLearnMore) footerLearnMore.addEventListener('click', openModal);
  if (modalCloseBtn) modalCloseBtn.addEventListener('click', closeModal);

  if (learnMoreModal) {
    learnMoreModal.addEventListener('click', (e) => {
      if (e.target === learnMoreModal) closeModal();
    });
  }

  if (modalCtaBtn) {
    modalCtaBtn.addEventListener('click', () => {
      closeModal();
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && learnMoreModal && learnMoreModal.classList.contains('active')) {
      closeModal();
    }
  });

  // ===== Countdown Timer =====
  // Set launch date to October 12 at 12:00 PM
  const nowObj = new Date();
  let targetYear = nowObj.getFullYear();
  let launchDate = new Date(targetYear, 9, 12, 12, 0, 0); // Month 9 = October
  if (launchDate.getTime() < nowObj.getTime()) {
    launchDate = new Date(targetYear + 1, 9, 12, 12, 0, 0);
  }

  function updateCountdown() {
    const now = new Date().getTime();
    const distance = launchDate.getTime() - now;

    if (distance <= 0) {
      document.getElementById('countdown-days').textContent = '00';
      document.getElementById('countdown-hours').textContent = '00';
      document.getElementById('countdown-minutes').textContent = '00';
      document.getElementById('countdown-seconds').textContent = '00';
      return;
    }

    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);

    document.getElementById('countdown-days').textContent = String(days).padStart(2, '0');
    document.getElementById('countdown-hours').textContent = String(hours).padStart(2, '0');
    document.getElementById('countdown-minutes').textContent = String(minutes).padStart(2, '0');
    document.getElementById('countdown-seconds').textContent = String(seconds).padStart(2, '0');
  }

  updateCountdown();
  setInterval(updateCountdown, 1000);

  // ===== Newsletter Subscription Form =====
  const subscribeForm = document.getElementById('subscribe-form');
  const subscribeEmail = document.getElementById('subscribe-email');
  const subscribeBtn = document.getElementById('subscribe-btn');
  const subscribeMessage = document.getElementById('subscribe-message');

  subscribeForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const email = subscribeEmail.value.trim();
    if (!email) return;

    // Show loading
    const btnText = subscribeBtn.querySelector('.btn-text');
    const btnLoader = subscribeBtn.querySelector('.btn-loader');
    btnText.style.display = 'none';
    btnLoader.style.display = 'inline-flex';
    subscribeBtn.disabled = true;

    try {
      const response = await fetch('/api/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });

      const data = await response.json();

      subscribeMessage.textContent = data.message;
      subscribeMessage.className = `form-message ${data.success ? 'success' : 'error'}`;

      if (data.success) {
        subscribeEmail.value = '';
        // Celebration animation
        celebrateSuccess(subscribeForm);
      }
    } catch (err) {
      subscribeMessage.textContent = 'Network error. Please try again.';
      subscribeMessage.className = 'form-message error';
    } finally {
      btnText.style.display = '';
      btnLoader.style.display = 'none';
      subscribeBtn.disabled = false;
    }
  });

  // ===== Contact Form =====
  const contactForm = document.getElementById('contact-form');
  const contactSubmitBtn = document.getElementById('contact-submit-btn');
  const contactMessageStatus = document.getElementById('contact-message-status');

  contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = document.getElementById('contact-name').value.trim();
    const email = document.getElementById('contact-email').value.trim();
    const subject = document.getElementById('contact-subject').value.trim();
    const message = document.getElementById('contact-message').value.trim();

    if (!name || !email || !message) return;

    // Show loading
    const btnText = contactSubmitBtn.querySelector('.btn-text');
    const btnLoader = contactSubmitBtn.querySelector('.btn-loader');
    const btnArrow = contactSubmitBtn.querySelector('.btn-arrow');
    btnText.style.display = 'none';
    if (btnArrow) btnArrow.style.display = 'none';
    btnLoader.style.display = 'inline-flex';
    contactSubmitBtn.disabled = true;

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, subject, message })
      });

      const data = await response.json();

      contactMessageStatus.textContent = data.message;
      contactMessageStatus.className = `form-message ${data.success ? 'success' : 'error'}`;

      if (data.success) {
        contactForm.reset();
        celebrateSuccess(contactForm);
      }
    } catch (err) {
      contactMessageStatus.textContent = 'Network error. Please try again.';
      contactMessageStatus.className = 'form-message error';
    } finally {
      btnText.style.display = '';
      if (btnArrow) btnArrow.style.display = '';
      btnLoader.style.display = 'none';
      contactSubmitBtn.disabled = false;
    }
  });

  // ===== Scroll Reveal Animations =====
  const revealElements = [
    ...document.querySelectorAll('.feature-card'),
    ...document.querySelectorAll('.section-header'),
    document.querySelector('.newsletter-wrapper'),
    document.querySelector('.contact-info'),
    document.querySelector('.contact-form-wrapper'),
    document.getElementById('hero-heading'),
    document.getElementById('hero-description'),
    document.getElementById('hero-cta'),
    document.getElementById('hero-visual'),
    document.getElementById('coming-soon-badge'),
  ].filter(Boolean);

  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        revealObserver.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  });

  revealElements.forEach((el, index) => {
    el.classList.add('reveal');
    el.style.transitionDelay = `${index * 0.05}s`;
    revealObserver.observe(el);
  });

  // ===== Features Grid Stagger =====
  const featuresGrid = document.querySelector('.features-grid');
  if (featuresGrid) {
    featuresGrid.classList.add('stagger-reveal');
    const gridObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          gridObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.2 });
    gridObserver.observe(featuresGrid);
  }

  // ===== Success Celebration (particle burst) =====
  function celebrateSuccess(target) {
    const rect = target.getBoundingClientRect();
    const colors = ['#C8FF00', '#ffffff', '#d4ff33', '#a0cc00'];

    for (let i = 0; i < 20; i++) {
      const particle = document.createElement('div');
      particle.style.cssText = `
        position: fixed;
        width: ${Math.random() * 6 + 3}px;
        height: ${Math.random() * 6 + 3}px;
        background: ${colors[Math.floor(Math.random() * colors.length)]};
        border-radius: 50%;
        left: ${rect.left + rect.width / 2}px;
        top: ${rect.top + rect.height / 2}px;
        pointer-events: none;
        z-index: 9999;
        transition: all ${Math.random() * 0.8 + 0.5}s cubic-bezier(0.25, 0.46, 0.45, 0.94);
      `;
      document.body.appendChild(particle);

      requestAnimationFrame(() => {
        particle.style.left = `${rect.left + rect.width / 2 + (Math.random() - 0.5) * 300}px`;
        particle.style.top = `${rect.top + rect.height / 2 + (Math.random() - 0.5) * 200 - 100}px`;
        particle.style.opacity = '0';
        particle.style.transform = `scale(0)`;
      });

      setTimeout(() => particle.remove(), 1500);
    }
  }

  // ===== Smooth Scroll for Anchor Links =====
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', (e) => {
      e.preventDefault();
      const target = document.querySelector(anchor.getAttribute('href'));
      if (target) {
        const offsetTop = target.offsetTop - 80;
        window.scrollTo({
          top: offsetTop,
          behavior: 'smooth'
        });
      }
    });
  });

  // ===== Parallax on Hero Card =====
  const heroCard = document.querySelector('.hero-card');
  if (heroCard && window.innerWidth > 1024) {
    document.addEventListener('mousemove', (e) => {
      const x = (e.clientX / window.innerWidth - 0.5) * 8;
      const y = (e.clientY / window.innerHeight - 0.5) * 8;
      heroCard.style.transform = `perspective(1000px) rotateY(${x}deg) rotateX(${-y}deg)`;
    });
  }
});
